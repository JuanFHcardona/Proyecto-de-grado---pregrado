Pasos para instalar firmware necesario en la esp8266 NodeMCU V3:

1. Buscar en la carpeta "Instalador" la carrpeta con la version de procesador para windows (Win32 o Win64).
2. Ingresar a la carpeta "Release" y correr el ejecutable ESP8266Flasher.exe.
3. Dentro del programa seleccionar el puerto (COM...) correspondiente a la ESP8266.
4. Ir al apartado "Config" y oprimir el engranaje de la primera fila y seleccionar el archivo de la carpeta "v1.3.0.2 AT Firmware.bin".
5. Ir al apartado "Advanced" y configurar el Baudrate (recomendado 115200), Flash size (4MB), Flash speed (80MHz) & DIO.
6. Volvemos al apartado principal y seleccionamos "Flash". Esperamos hasta que finalice la instalación. 